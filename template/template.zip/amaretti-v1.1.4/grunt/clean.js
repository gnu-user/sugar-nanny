/*Dist remove folders*/

module.exports = {
  dist:{
    src: ['dist']
  }
};