/*!
 * Amaretti - Documentation v0.0.1 (http://foxythemes.net/themes/amaretti)
 * Copyright 2014-2015 Foxy Themes all rights reserved 
 */
var App=function(){return{init:function(a){prettyPrint()}}}();